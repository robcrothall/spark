<div>
<img src="../assets/img/construction.gif" alt="Under construction">
</div>