<h2 align="center">Users</h2>
<form action="user.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="username" placeholder="Username" type="text"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="password" placeholder="Password" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="confirmation" placeholder="Re-enter Password" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="surname" placeholder="Surname" type="text"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="first_name" placeholder="First name" type="text"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="phone" placeholder="Phone number" type="text"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="mobile" placeholder="Mobile number" type="text"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="email" placeholder="Email address" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Submit</button>
        </div>
    </fieldset>
</form>
