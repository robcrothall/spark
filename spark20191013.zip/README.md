# spark
Settlers Park Retirement Village intranet
2019-10-13
Settlers park Retirement Villageintranet project provides a service where staff and 
Residents of the Park can access internal services and documents.

If any information found on the site is thought to be inaccurate or inappropriate, 
please send details to info@settlerspark.co.za .
