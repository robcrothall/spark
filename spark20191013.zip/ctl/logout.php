<?php

    // configuration
    require("../conf/config.php"); 

    // log out current user, if any
    logout();

    // redirect user
    redirect("https://www.kowiemuseum.co.za");

?>
