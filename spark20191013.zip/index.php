<!DOCTYPE html>
<html>
  <HEAD>
    <META http-equiv="refresh" content="0; url=https://kiss.zacs.co.za/spark/ctl/login.php"/>
    <META http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
    <META http-equiv="Pragma" content="no-cache"/>
    <META http-equiv="Expires" content="0"/>
  </HEAD>
</html>
